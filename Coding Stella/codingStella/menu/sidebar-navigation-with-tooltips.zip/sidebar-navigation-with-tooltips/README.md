# sidebar navigation with tooltips

A Pen created on CodePen.io. Original URL: [https://codepen.io/pixelsultan/pen/WrWZpd](https://codepen.io/pixelsultan/pen/WrWZpd).

